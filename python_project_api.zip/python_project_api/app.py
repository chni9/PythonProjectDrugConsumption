from flask import Flask,request, url_for, redirect, render_template
import pickle
import numpy as np

app = Flask(__name__)
model1=pickle.load(open("finalized_model_age.pkl",'rb'))
model2=pickle.load(open("finalized_model_gender.pkl",'rb'))
model3=pickle.load(open("finalized_model_education.pkl",'rb'))
model4=pickle.load(open("finalized_model_country.pkl",'rb'))
model5=pickle.load(open("finalized_model_ethnicity.pkl",'rb'))



@app.route('/')
def hello_world():
    return render_template("forest_fire.html")


@app.route('/predict',methods=['POST','GET'])

def predict(score1,score2,score3):
    I=np.array([score1,score2,score3]).reshape(1,3)

    age=model1.predict(I)[0]
    gender=model2.predict(I)[0]
    education=model3.predict(I)[0]
    country=model4.predict(I)[0]
    ethnicity=model5.predict(I)[0]
    s=""
    s+="\n"+"Individual : "+"\n"+"Age : "+age+"\n"+"Gender : "+gender+"\n"+"Education : "+education+"\n"+"Country : "+country+"\n"+"Ethnicity : "+ethnicity
    return s



if __name__ == '__main__':
    app.run(debug=True)